#!/bin/sh
# Mac / Linux launcher. Taichi only supports Python 3.10-3.12.
cd "$(dirname "$0")" || exit 1

if command -v uv >/dev/null 2>&1; then
  echo "Using uv - it fetches Python 3.12 + taichi automatically..."
  exec uv run --python 3.12 --with taichi kerr_blackhole.py "$@"
fi

for v in 3.12 3.11 3.10; do
  if command -v "python$v" >/dev/null 2>&1; then
    echo "Using python$v ..."
    [ -d .venv ] || "python$v" -m venv .venv
    ./.venv/bin/python -m pip install --quiet -r requirements.txt
    exec ./.venv/bin/python kerr_blackhole.py "$@"
  fi
done

echo ""
echo "  No compatible Python found. Taichi needs 3.10 - 3.12 (3.13/3.14 will NOT work)."
echo ""
echo "  Easiest fix - install uv, then run this script again:"
echo ""
echo "    curl -LsSf https://astral.sh/uv/install.sh | sh"
echo ""
exit 1

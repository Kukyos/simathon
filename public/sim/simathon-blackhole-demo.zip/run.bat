@echo off
setlocal
cd /d "%~dp0"
rem Taichi only supports Python 3.10-3.12. This finds one or tells you the fix.

where uv >nul 2>nul && (
  echo Using uv - it fetches Python 3.12 + taichi automatically...
  uv run --python 3.12 --with taichi kerr_blackhole.py %*
  if errorlevel 1 pause
  goto end
)

py -3.12 -c "" >nul 2>nul && set "PY=py -3.12" && goto run
py -3.11 -c "" >nul 2>nul && set "PY=py -3.11" && goto run
py -3.10 -c "" >nul 2>nul && set "PY=py -3.10" && goto run

echo(
echo   No compatible Python found. Taichi needs Python 3.10 - 3.12
echo   (3.13 / 3.14 will NOT work).
echo(
echo   Easiest fix - copy this one line into PowerShell, then re-run run.bat:
echo(
echo     powershell -ExecutionPolicy Bypass -c "irm https://astral.sh/uv/install.ps1 | iex"
echo(
echo   Or install Python 3.12 from python.org/downloads (scroll past the
echo   big button to "Looking for a specific release?").
echo(
pause
goto end

:run
echo Using %PY% ...
if not exist .venv %PY% -m venv .venv
.venv\Scripts\python -m pip install --quiet -r requirements.txt
.venv\Scripts\python kerr_blackhole.py %*
if errorlevel 1 pause

:end
endlocal

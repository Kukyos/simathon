"""SHOW_physics.py — display copy for the workshop, not imported.

The real file is kerr_blackhole.py (~500 lines). Most of it is camera,
colors, bloom, UI. THIS is the physics core, copied here so it fits on
one screen. The full derivation is on the site: /blackhole.

The one-sentence version:
  For every pixel, fire a light ray BACKWARDS from the camera and let
  Einstein's equations bend it. Whatever it hits is that pixel's color.
  ~1 million rays per frame, each one solving 5 differential equations.
"""

# ---------------------------------------------------------------------------
# 1. THE GEOMETRY. Kerr metric = the exact solution of Einstein's field
#    equations for a spinning black hole (Roy Kerr, 1963).
#    A photon's path comes from Hamilton's equations, the same mechanics
#    framework as high-school physics, just in curved spacetime.
#    (kerr_blackhole.py: geodesic_rhs, lines ~98-121)
# ---------------------------------------------------------------------------
@ti.func
def geodesic_rhs(y, E, L, a):
    r, th, pr, pth = y[0], y[1], y[3], y[4]
    sigma = r * r + a * a * ti.cos(th) ** 2       # Σ = r² + a²cos²θ
    delta = r * r - 2.0 * r + a * a               # Δ = r² - 2r + a²  (horizon: Δ=0)
    P  = E * (r * r + a * a) - a * L
    Wt = L / ti.sin(th) - a * E * ti.sin(th)
    # ... Hamilton's equations: dr/dλ = ∂H/∂p_r,  dp_r/dλ = -∂H/∂r, etc.
    dr  = delta * pr / sigma
    dth = pth / sigma
    dph = (a * P / delta + Wt / ti.sin(th)) / sigma
    # (momentum derivatives omitted here; see the real file)
    return ti.Vector([dr, dth, dph, ...])

# ---------------------------------------------------------------------------
# 2. THE INTEGRATOR. RK4: the workhorse method for solving differential
#    equations numerically. Take 4 trial steps, blend them. Repeat up to
#    ~400 times per ray until it hits the disk, escapes, or falls in.
#    (kerr_blackhole.py: rk4_step, lines ~124-130)
# ---------------------------------------------------------------------------
@ti.func
def rk4_step(y, h, E, L, a):
    k1 = geodesic_rhs(y, E, L, a)
    k2 = geodesic_rhs(y + 0.5 * h * k1, E, L, a)
    k3 = geodesic_rhs(y + 0.5 * h * k2, E, L, a)
    k4 = geodesic_rhs(y + h * k3, E, L, a)
    return y + (h / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)

# ---------------------------------------------------------------------------
# 3. THE COLORS. When a ray hits the disk, ALL the relativity collapses
#    into one number g = observed/emitted photon energy:
#       gravitational redshift + Doppler shift, combined, exact.
#    Brightness scales as g^4 (that's why one side of the disk is brighter,
#    same as the real Event Horizon Telescope images). Color is a blackbody
#    at temperature g*T: approaching side hotter/bluer, receding redder.
#    (kerr_blackhole.py: shade_disk, lines ~215-239)
# ---------------------------------------------------------------------------
@ti.func
def shade_disk(r, ph, E, L, a, rin, t):
    om = 1.0 / (r ** 1.5 + a)                     # orbital speed at radius r
    ut = orbit_four_velocity(r, om, a)
    gfac = 1.0 / (ut * (E - om * L))              # THE redshift factor
    T_emitted = disk_temperature(r, rin)          # friction heats the gas
    intensity = gfac ** 4                         # relativistic beaming
    return blackbody_rgb(gfac * T_emitted) * intensity

# ---------------------------------------------------------------------------
# Nothing here is decoration: the shadow size (2.6x the horizon), the bright
# photon ring, the D-shaped shadow when it spins, the "Interstellar" band of
# light arcing over the top - none of that is programmed in. It EMERGES from
# the equations. Run `python kerr_blackhole.py --check` to verify against
# exact textbook numbers.
# ---------------------------------------------------------------------------

"""
kerr_blackhole.py — Simathon demo: a real Kerr black-hole ray tracer.

This is NOT a particle toy. Every pixel is a photon traced backwards from the
camera along an exact null geodesic of the Kerr metric (a rotating black hole),
integrated as Hamiltonian flow with RK4. The accretion disk is shaded with the
exact general-relativistic redshift factor (gravitational redshift + Doppler
combined), relativistic beaming (g^4), and blackbody color.

Units: geometric, G = c = M = 1. The horizon is at r+ = 1 + sqrt(1 - a^2).
Equation numbers "EQ (n)" match the physics page on the workshop site.

Run:      python kerr_blackhole.py            (needs: pip install taichi)
Verify:   python kerr_blackhole.py --check    (headless physics self-tests)

Controls:
  drag mouse      orbit camera            scroll / W,S   zoom in/out
  A / D           spin a down/up          SPACE          pause disk time
  P               save screenshot         ESC            quit
  (sliders in the on-screen panel for spin, inclination, FOV, exposure)
"""

import argparse
import math
import sys
import time

import taichi as ti

parser = argparse.ArgumentParser()
parser.add_argument("--check", action="store_true", help="run physics self-tests headless and exit")
parser.add_argument("--bench", type=str, default="", help="render offscreen, save PNG to this path, exit")
parser.add_argument("--quality", choices=["low", "med", "high"], default="med")
parser.add_argument("--spin", type=float, default=0.85, help="black hole spin a in [0, 0.995]")
args = parser.parse_args()

try:
    ti.init(arch=ti.gpu)
except Exception:
    ti.init(arch=ti.cpu)
    print("WARNING: no GPU backend, running on CPU. Use --quality low.")

# ---------------------------------------------------------------- settings --
QUALITY = {"low": (800, 450, 300), "med": (1152, 648, 420), "high": (1440, 810, 560)}
W, H, MAX_STEPS = QUALITY[args.quality]

R_ESCAPE = 60.0        # a ray past this radius (moving out) has left the system
DISK_OUT = 18.0        # outer edge of the accretion disk, in M
T_PEAK = 8000.0        # disk peak temperature in Kelvin (sets the color scheme)
H0 = 0.16              # base affine-parameter step for RK4

vec2 = ti.math.vec2
vec3 = ti.math.vec3

# runtime parameters live in 0-D fields so kernels always see current values
spin = ti.field(ti.f32, shape=())        # a
cam_r = ti.field(ti.f32, shape=())
cam_th = ti.field(ti.f32, shape=())      # inclination (pi/2 = edge-on)
cam_ph = ti.field(ti.f32, shape=())
fov = ti.field(ti.f32, shape=())
exposure = ti.field(ti.f32, shape=())
r_isco = ti.field(ti.f32, shape=())
r_hor = ti.field(ti.f32, shape=())
disk_t = ti.field(ti.f32, shape=())      # disk rotation clock

col_new = ti.Vector.field(3, ti.f32, shape=(W, H))   # this frame, linear
col_acc = ti.Vector.field(3, ti.f32, shape=(W, H))   # temporal average, linear
bloom_a = ti.Vector.field(3, ti.f32, shape=(W, H))
bloom_b = ti.Vector.field(3, ti.f32, shape=(W, H))
img = ti.Vector.field(3, ti.f32, shape=(W, H))       # tonemapped output


def isco_radius(a: float) -> float:
    """EQ (5): Bardeen ISCO for a prograde equatorial orbit. a=0 -> 6M, a=1 -> 1M."""
    z1 = 1.0 + (1.0 - a * a) ** (1 / 3) * ((1.0 + a) ** (1 / 3) + (1.0 - a) ** (1 / 3))
    z2 = math.sqrt(3.0 * a * a + z1 * z1)
    return 3.0 + z2 - math.sqrt((3.0 - z1) * (3.0 + z1 + 2.0 * z2))


def set_spin(a: float):
    a = min(max(a, 0.0), 0.995)
    spin[None] = a
    r_hor[None] = 1.0 + math.sqrt(1.0 - a * a)
    r_isco[None] = isco_radius(a)


# ------------------------------------------------------------ geodesics -----
# State vector y = (r, theta, phi, p_r, p_theta). E and L_z are conserved.
#
# EQ (2): the super-Hamiltonian of a Kerr photon, in the separated form
#   H = [ Delta p_r^2 + p_th^2 - P(r)^2/Delta + W(th)^2 ] / (2 Sigma)
#   P = E (r^2 + a^2) - a L_z          W = L_z/sin th - a E sin th
#   Sigma = r^2 + a^2 cos^2 th         Delta = r^2 - 2r + a^2
# H = 0 along every light ray; we monitor it as an integration-error gauge.
#
# EQ (3): Hamilton's equations dy/dlambda = (dH/dp, -dH/dq), all analytic below.

@ti.func
def geodesic_rhs(y, E: ti.f32, L: ti.f32, a: ti.f32):
    r, th, pr, pth = y[0], y[1], y[3], y[4]
    s = ti.sin(th)
    c = ti.cos(th)
    s = ti.max(ti.abs(s), 1e-5) * (1.0 if s >= 0 else -1.0)
    sigma = r * r + a * a * c * c
    delta = r * r - 2.0 * r + a * a
    P = E * (r * r + a * a) - a * L
    Wt = L / s - a * E * s

    F = delta * pr * pr + pth * pth - P * P / delta + Wt * Wt
    Hc = F / (2.0 * sigma)

    dr = delta * pr / sigma
    dth = pth / sigma
    dph = (a * P / delta + Wt / s) / sigma

    ddel = 2.0 * r - 2.0
    Fr = ddel * pr * pr - (2.0 * P * (2.0 * E * r) * delta - P * P * ddel) / (delta * delta)
    Fth = 2.0 * Wt * (-L * c / (s * s) - a * E * c)
    dpr = -(Fr - 2.0 * Hc * (2.0 * r)) / (2.0 * sigma)
    dpth = -(Fth - 2.0 * Hc * (-2.0 * a * a * s * c)) / (2.0 * sigma)
    return ti.Vector([dr, dth, dph, dpr, dpth])


@ti.func
def rk4_step(y, h: ti.f32, E: ti.f32, L: ti.f32, a: ti.f32):
    k1 = geodesic_rhs(y, E, L, a)
    k2 = geodesic_rhs(y + 0.5 * h * k1, E, L, a)
    k3 = geodesic_rhs(y + 0.5 * h * k2, E, L, a)
    k4 = geodesic_rhs(y + h * k3, E, L, a)
    return y + (h / 6.0) * (k1 + 2.0 * k2 + 2.0 * k3 + k4)


# --------------------------------------------------------------- camera -----
# EQ (4): the camera is a ZAMO (zero-angular-momentum observer) — the locally
# non-rotating frame. Its orthonormal tetrad turns a pixel's view direction
# into the photon's conserved (E, L_z) and initial momenta (p_r, p_th).

@ti.func
def camera_ray(nr: ti.f32, nth: ti.f32, nph: ti.f32, r: ti.f32, th: ti.f32, a: ti.f32):
    s = ti.sin(th)
    c = ti.cos(th)
    sigma = r * r + a * a * c * c
    delta = r * r - 2.0 * r + a * a
    A2 = (r * r + a * a) ** 2 - a * a * delta * s * s
    g_tt = -(1.0 - 2.0 * r / sigma)
    g_tp = -2.0 * a * r * s * s / sigma
    g_pp = A2 * s * s / sigma
    omega = 2.0 * a * r / A2                       # frame-dragging rate
    alpha = ti.sqrt(delta * sigma / A2)            # lapse

    pt = 1.0 / alpha
    pp = omega / alpha + nph / ti.sqrt(g_pp)
    E = -(g_tt * pt + g_tp * pp)
    L = g_tp * pt + g_pp * pp
    p_r = nr * ti.sqrt(sigma / delta)
    p_th = nth * ti.sqrt(sigma)
    return E, L, p_r, p_th


# ----------------------------------------------------------------- disk -----
@ti.func
def hash21(p):
    return ti.math.fract(ti.sin(p.dot(vec2(127.1, 311.7))) * 43758.5453)


@ti.func
def vnoise(p):
    i = ti.floor(p)
    f = ti.math.fract(p)
    u = f * f * (3.0 - 2.0 * f)
    a = hash21(i)
    b = hash21(i + vec2(1, 0))
    c = hash21(i + vec2(0, 1))
    d = hash21(i + vec2(1, 1))
    return ti.math.mix(ti.math.mix(a, b, u.x), ti.math.mix(c, d, u.x), u.y)


@ti.func
def fbm(p):
    v = 0.0
    amp = 0.5
    q = p
    for _ in range(4):
        v += amp * vnoise(q)
        q = vec2(0.8 * q.x - 0.6 * q.y, 0.6 * q.x + 0.8 * q.y) * 2.03  # rotate octaves
        amp *= 0.5
    return v


@ti.func
def disk_temperature(r: ti.f32, rin: ti.f32) -> ti.f32:
    # EQ (9): Shakura–Sunyaev thin-disk profile, T ~ r^-3/4 (1 - sqrt(rin/r))^1/4,
    # normalized so the peak (at r = 49/36 rin) is T_PEAK.
    x = ti.max(r / rin, 1.0001)
    f = x ** -0.75 * (1.0 - ti.sqrt(1.0 / x)) ** 0.25
    return T_PEAK * f / 0.4879


@ti.func
def blackbody_rgb(T: ti.f32):
    # EQ (10): Planckian locus -> sRGB (Tanner Helland fit), T in Kelvin.
    t = ti.math.clamp(T, 1000.0, 40000.0) / 100.0
    r, g, b = 1.0, 1.0, 1.0
    if t <= 66.0:
        g = ti.math.clamp((99.4708025861 * ti.log(t) - 161.1195681661) / 255.0, 0.0, 1.0)
        b = 0.0
        if t > 19.0:
            b = ti.math.clamp((138.5177312231 * ti.log(t - 10.0) - 305.0447927307) / 255.0, 0.0, 1.0)
    else:
        r = ti.math.clamp(329.698727446 * (t - 60.0) ** -0.1332047592 / 255.0, 0.0, 1.0)
        g = ti.math.clamp(288.1221695283 * (t - 60.0) ** -0.0755148492 / 255.0, 0.0, 1.0)
    return vec3(r, g, b)


@ti.func
def shade_disk(r: ti.f32, ph: ti.f32, E: ti.f32, L: ti.f32, a: ti.f32,
               rin: ti.f32, t: ti.f32):
    # EQ (6): prograde circular-orbit angular velocity Omega = 1/(r^1.5 + a).
    om = 1.0 / (r ** 1.5 + a)
    # equatorial metric components (theta = pi/2, Sigma = r^2)
    g_tt = -(1.0 - 2.0 / r)
    g_tp = -2.0 * a / r
    g_pp = r * r + a * a + 2.0 * a * a / r
    ut2 = -(g_tt + 2.0 * om * g_tp + om * om * g_pp)
    col = vec3(0.0)
    if ut2 > 1e-6:
        ut = 1.0 / ti.sqrt(ut2)                       # orbit 4-velocity u^t
        # EQ (7): redshift factor g = E_cam / E_emitted = 1 / [u^t (E - Omega L_z)].
        # This single number contains gravitational redshift AND Doppler shift.
        gfac = ti.min(1.0 / (ut * (E - om * L)), 4.0)
        T_em = disk_temperature(r, rin)
        # turbulence, co-rotating with the local orbit -> differential shear
        pco = vec2(r * ti.cos(ph - om * t), r * ti.sin(ph - om * t))
        tex = 0.22 + 1.3 * fbm(pco * 1.3) ** 2
        # EQ (8): relativistic beaming — bolometric intensity transforms as g^4,
        # and the observed spectrum is a blackbody at g * T_em.
        inten = gfac ** 4 * (T_em / T_PEAK) ** 4 * tex
        col = blackbody_rgb(gfac * T_em) * inten * 1.6
    return col


# ------------------------------------------------------------------ sky -----
@ti.func
def hash31(p):
    return ti.math.fract(ti.sin(p.dot(vec3(17.1, 31.7, 61.3))) * 43758.5453)


@ti.func
def sky_color(d):
    # procedural starfield; the lensing warps it into Einstein arcs for free
    col = vec3(0.004, 0.005, 0.010)
    band = ti.exp(-4.5 * (d.y + 0.35 * d.x) ** 2)     # faint galactic band
    col += vec3(0.030, 0.026, 0.038) * band * (0.4 + 0.6 * fbm(vec2(d.x + 2.0 * d.z, d.y) * 5.0))
    p = d * 48.0
    cell = ti.floor(p)
    rnd = hash31(cell)
    if rnd > 0.90:
        sp = cell + 0.5 + 0.6 * (vec3(hash31(cell + 1.3), hash31(cell + 2.7), hash31(cell + 4.1)) - 0.5)
        sd = sp.normalized()
        ang = ti.acos(ti.math.clamp(d.dot(sd), -1.0, 1.0))
        tint = ti.math.mix(vec3(0.75, 0.82, 1.0), vec3(1.0, 0.85, 0.7), hash31(cell + 9.9))
        col += tint * (rnd - 0.90) * 26.0 * ti.exp(-(ang / 0.0035) ** 2)
    return col


# ---------------------------------------------------------------- render ----
@ti.kernel
def render(t: ti.f32, jx: ti.f32, jy: ti.f32):
    a = spin[None]
    rc, thc, phc = cam_r[None], cam_th[None], cam_ph[None]
    tanf = ti.tan(fov[None] * 0.5)
    rin = r_isco[None]
    rstop = r_hor[None] + 0.02
    for i, j in col_new:
        u = (i + 0.5 + jx - 0.5 * W) / H
        v = (j + 0.5 + jy - 0.5 * H) / H
        # view direction in the camera's local orthonormal frame (r^, th^, ph^)
        n = vec3(-1.0, -tanf * v, tanf * u).normalized()   # (n_r, n_th, n_ph)
        E, L, pr0, pth0 = camera_ray(n.x, n.y, n.z, rc, thc, a)
        y = ti.Vector([rc, thc, phc, pr0, pth0])

        out = vec3(0.0)
        done = 0
        step = 0
        while done == 0 and step < MAX_STEPS:
            # adaptive step: shrink near the horizon and near the polar axis
            hs = H0 * ti.math.clamp(y[0] * 0.25, 0.04, 2.2)
            hs *= ti.math.clamp((y[0] - rstop) * 2.0, 0.05, 1.0)
            hs *= ti.math.clamp(ti.abs(ti.sin(y[1])) * 10.0, 0.05, 1.0)
            yn = rk4_step(y, hs, E, L, a)

            c0 = ti.cos(y[1])
            c1 = ti.cos(yn[1])
            if c0 * c1 < 0.0:                          # crossed the equator
                f = c0 / (c0 - c1)
                rx = ti.math.mix(y[0], yn[0], f)
                if rx >= rin and rx <= DISK_OUT:       # hit the disk (opaque)
                    px = ti.math.mix(y[2], yn[2], f)
                    out = shade_disk(rx, px, E, L, a, rin, t)
                    done = 1
            if done == 0:
                if yn[0] < rstop:                      # captured: the shadow
                    done = 2
                elif yn[0] > R_ESCAPE and yn[0] > y[0]:  # escaped: sample sky
                    d = geodesic_rhs(yn, E, L, a)
                    sth, cth = ti.sin(yn[1]), ti.cos(yn[1])
                    sph, cph = ti.sin(yn[2]), ti.cos(yn[2])
                    r1 = yn[0]
                    dx = d[0] * sth * cph + r1 * cth * cph * d[1] - r1 * sth * sph * d[2]
                    dy = d[0] * sth * sph + r1 * cth * sph * d[1] + r1 * sth * cph * d[2]
                    dz = d[0] * cth - r1 * sth * d[1]
                    out = sky_color(vec3(dx, dy, dz).normalized())
                    done = 3
            y = yn
            step += 1
        if done == 0 and y[0] > DISK_OUT:
            # ran out of steps far from the hole (stiff near-axis ray): the sky
            d = geodesic_rhs(y, E, L, a)
            sth, cth = ti.sin(y[1]), ti.cos(y[1])
            sph, cph = ti.sin(y[2]), ti.cos(y[2])
            r1 = y[0]
            dx = d[0] * sth * cph + r1 * cth * cph * d[1] - r1 * sth * sph * d[2]
            dy = d[0] * sth * sph + r1 * cth * sph * d[1] + r1 * sth * cph * d[2]
            dz = d[0] * cth - r1 * sth * d[1]
            out = sky_color(vec3(dx, dy, dz).normalized())
        col_new[i, j] = out


@ti.kernel
def blend(alpha: ti.f32):
    for i, j in col_acc:
        col_acc[i, j] = ti.math.mix(col_acc[i, j], col_new[i, j], alpha)


@ti.kernel
def bloom_extract_h():
    for i, j in bloom_a:
        acc = vec3(0.0)
        wsum = 0.0
        for k in ti.static(range(-6, 7)):
            x = ti.math.clamp(i + k * 2, 0, W - 1)
            w = ti.exp(-0.5 * (k / 3.0) ** 2)
            c = col_acc[x, j] * exposure[None]
            acc += ti.max(c - 1.0, 0.0) * w
            wsum += w
        bloom_a[i, j] = acc / wsum


@ti.kernel
def bloom_v_compose():
    for i, j in img:
        acc = vec3(0.0)
        wsum = 0.0
        for k in ti.static(range(-6, 7)):
            y = ti.math.clamp(j + k * 2, 0, H - 1)
            w = ti.exp(-0.5 * (k / 3.0) ** 2)
            acc += bloom_a[i, y] * w
            wsum += w
        c = col_acc[i, j] * exposure[None] + 0.7 * acc / wsum
        # ACES filmic tonemap + gamma
        m = c * (2.51 * c + 0.03) / (c * (2.43 * c + 0.59) + 0.14)
        img[i, j] = ti.math.clamp(m, 0.0, 1.0) ** (1.0 / 2.2)


# ------------------------------------------------------------ self-tests ----
test_out = ti.field(ti.f32, shape=2)   # [0] = 1 if captured, [1] = max |H| drift


@ti.kernel
def trace_test_ray(b: ti.f32, a: ti.f32):
    for _one in range(1):  # single outer iteration -> inner loop stays serial
        r0 = 200.0
        nph = b / r0
        n = vec3(-ti.sqrt(1.0 - nph * nph), 0.0, nph)
        E, L, pr0, pth0 = camera_ray(n.x, n.y, n.z, r0, math.pi / 2, a)
        y = ti.Vector([r0, math.pi / 2, 0.0, pr0, pth0])
        rstop = 1.0 + ti.sqrt(1.0 - a * a) + 0.02
        captured = 0.0
        hmax = 0.0
        for _ in range(40000):
            if y[0] < rstop:
                captured = 1.0
                break
            if y[0] > 250.0:
                break
            hs = 0.05 * ti.math.clamp(y[0] * 0.25, 0.02, 2.0)
            y = rk4_step(y, hs, E, L, a)
            # recompute H (should stay 0 — EQ (2)); gauged away from the
            # horizon, where Delta -> 0 makes the f32 cancellation meaningless
            if y[0] > 3.0:
                s = ti.sin(y[1])
                sg = y[0] * y[0] + a * a * ti.cos(y[1]) ** 2
                dl = y[0] * y[0] - 2.0 * y[0] + a * a
                P = E * (y[0] * y[0] + a * a) - a * L
                Wt = L / s - a * E * s
                Hh = (dl * y[3] ** 2 + y[4] ** 2 - P * P / dl + Wt * Wt) / (2.0 * sg)
                hmax = ti.max(hmax, ti.abs(Hh))
        test_out[0] = captured
        test_out[1] = hmax


def run_checks():
    # Schwarzschild critical impact parameter is b_crit = 3*sqrt(3) M = 5.196.
    # A ray aimed inside it must be captured, outside it must escape.
    ok = True
    for b, expect in [(4.9, 1.0), (5.5, 0.0)]:
        trace_test_ray(b, 0.0)
        got, hdrift = test_out[0], test_out[1]
        status = "PASS" if got == expect else "FAIL"
        ok &= got == expect
        print(f"[{status}] a=0 ray, b={b}M -> {'captured' if got else 'escaped'} "
              f"(expected {'captured' if expect else 'escaped'}), max|H| drift {hdrift:.2e}")
        ok &= hdrift < 5e-3
    # spinning hole, a=0.95: the critical impact parameters are asymmetric
    # (prograde +2.58M, retrograde -6.92M) because of frame dragging.
    trace_test_ray(-6.3, 0.95)
    ok &= test_out[0] == 1.0
    print(f"[{'PASS' if test_out[0] == 1.0 else 'FAIL'}] a=0.95 retrograde b=-6.3M captured (dragging widens the retrograde shadow)")
    trace_test_ray(3.2, 0.95)
    ok &= test_out[0] == 0.0
    print(f"[{'PASS' if test_out[0] == 0.0 else 'FAIL'}] a=0.95 prograde b=+3.2M escapes (a=0 would capture it; dragging saves it)")
    print("ISCO check: a=0 ->", round(isco_radius(0.0), 4), "M (expect 6),  a=0.998 ->",
          round(isco_radius(0.998), 4), "M (expect ~1.23)")
    assert ok, "physics self-test FAILED"
    print("all physics checks passed.")


# ------------------------------------------------------------------ main ----
def main():
    set_spin(args.spin)
    cam_r[None] = 24.0
    cam_th[None] = math.radians(82.0)   # nearly edge-on: the cinematic view
    cam_ph[None] = 0.0
    fov[None] = math.radians(55.0)
    exposure[None] = 0.9

    try:
        window = ti.ui.Window("Kerr black hole — Simathon", (W, H))
    except Exception as e:
        print("Could not open a window (GPU/Vulkan drivers?). Error:", e)
        sys.exit(1)
    canvas = window.get_canvas()
    gui = window.get_gui()

    print(__doc__)
    print(f"spin a={spin[None]:.3f}  horizon r+={r_hor[None]:.3f}M  ISCO={r_isco[None]:.3f}M")

    paused = False
    frame = 0
    last_mouse = None
    t0 = time.time()
    while window.running:
        moved = False
        for e in window.get_events(ti.ui.PRESS):
            if e.key == ti.ui.ESCAPE:
                window.running = False
            elif e.key == ti.ui.SPACE:
                paused = not paused
            elif e.key == "p":
                window.save_image(f"kerr_{frame}.png")
                print(f"saved kerr_{frame}.png")

        if window.is_pressed("a"):
            set_spin(spin[None] - 0.004); moved = True
        if window.is_pressed("d"):
            set_spin(spin[None] + 0.004); moved = True
        if window.is_pressed("w"):
            cam_r[None] = max(r_hor[None] * 2.2, cam_r[None] * 0.985); moved = True
        if window.is_pressed("s"):
            cam_r[None] = min(55.0, cam_r[None] * 1.015); moved = True

        if window.is_pressed(ti.ui.LMB):
            mx, my = window.get_cursor_pos()
            if last_mouse is not None:
                dx, dy = mx - last_mouse[0], my - last_mouse[1]
                if abs(dx) + abs(dy) > 1e-5:
                    cam_ph[None] += dx * 3.0
                    cam_th[None] = min(max(cam_th[None] - dy * 2.0, 0.05), math.pi - 0.05)
                    moved = True
            last_mouse = (mx, my)
        else:
            last_mouse = None

        with gui.sub_window("Kerr", 0.015, 0.015, 0.27, 0.24) as sw:
            sw.text(f"horizon r+ = {r_hor[None]:.2f} M   ISCO = {r_isco[None]:.2f} M")
            new_a = sw.slider_float("spin a", spin[None], 0.0, 0.995)
            new_th = sw.slider_float("incl (deg)", math.degrees(cam_th[None]), 3.0, 177.0)
            new_fov = sw.slider_float("fov (deg)", math.degrees(fov[None]), 20.0, 90.0)
            exposure[None] = sw.slider_float("exposure", exposure[None], 0.2, 5.0)
        if abs(new_a - spin[None]) > 1e-4:
            set_spin(new_a); moved = True
        if abs(new_th - math.degrees(cam_th[None])) > 1e-3:
            cam_th[None] = math.radians(new_th); moved = True
        if abs(new_fov - math.degrees(fov[None])) > 1e-3:
            fov[None] = math.radians(new_fov); moved = True

        if not paused:
            disk_t[None] += 0.35        # advances the disk's orbital clock

        # sub-pixel jitter + temporal blend = free antialiasing
        jx = (hash(frame * 2654435761 % 1013) % 1000) / 1000.0 - 0.5
        jy = (hash(frame * 40503 % 1013) % 1000) / 1000.0 - 0.5
        render(disk_t[None], jx * 0.9, jy * 0.9)
        blend(0.55 if moved else 0.16)
        bloom_extract_h()
        bloom_v_compose()
        canvas.set_image(img)
        window.show()
        frame += 1
        if frame % 120 == 0:
            fps = frame / (time.time() - t0)
            print(f"~{fps:.0f} fps | a={spin[None]:.3f} incl={math.degrees(cam_th[None]):.0f}deg r_cam={cam_r[None]:.1f}M", end="\r")


def bench(path: str):
    set_spin(args.spin)
    cam_r[None] = 24.0
    cam_th[None] = math.radians(82.0)
    cam_ph[None] = 0.0
    fov[None] = math.radians(55.0)
    exposure[None] = 0.9
    t0 = time.time()
    n = 24
    for f in range(n):
        disk_t[None] += 0.35
        render(disk_t[None], (f % 4) * 0.25 - 0.375, (f // 4 % 4) * 0.25 - 0.375)
        blend(1.0 if f == 0 else 0.2)
    bloom_extract_h()
    bloom_v_compose()
    ti.sync()
    dt = (time.time() - t0) / n
    ti.tools.imwrite(img.to_numpy(), path)
    print(f"{W}x{H}, {n} frames, {dt * 1000:.0f} ms/frame (~{1 / dt:.0f} fps). Saved {path}")


if __name__ == "__main__":
    if args.check:
        set_spin(args.spin)
        run_checks()
    elif args.bench:
        bench(args.bench)
    else:
        main()

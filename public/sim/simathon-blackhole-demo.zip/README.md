# Kerr Black Hole Ray Tracer — the Simathon demo

A real-time, physically accurate simulation of a **rotating (Kerr) black hole**,
written in a single Python file with [Taichi](https://taichi-lang.org) for GPU
compute. Nothing here is faked with a distortion filter: **every pixel is a
photon traced backwards from the camera along an exact null geodesic of the
Kerr metric.**

![What you get](https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Black_hole_-_Messier_87.jpg/320px-Black_hole_-_Messier_87.jpg)
*(not our render — that's the real M87\* from the Event Horizon Telescope.
Run the sim and compare the shadow shape yourself.)*

## Run it

**Windows:** double-click `run.bat`.
**Mac / Linux:** `sh run.sh`

The launcher finds a Taichi-compatible Python (3.10–3.12) on your machine — or,
if you have [uv](https://docs.astral.sh/uv/), fetches one automatically. If it
finds neither, it prints the one-line fix.

> Taichi does **not** support Python 3.13 / 3.14, so a plain
> `pip install taichi` on a new Python install fails with
> `No matching distribution found`. That's why the launcher exists.

Manual route, if you already have Python 3.10–3.12:

```bash
pip install taichi
python kerr_blackhole.py
```

A dedicated GPU is strongly recommended (`--quality low` for laptops / CPU).

## Controls

| Input | Action |
|---|---|
| mouse drag | orbit the camera |
| `W` / `S` | zoom in / out |
| `A` / `D` | spin the black hole down / up |
| on-screen sliders | spin, inclination, field of view, exposure |
| `SPACE` | freeze the disk's orbital motion |
| `P` | screenshot |
| `ESC` | quit |

Watch what happens to the **shape of the shadow** as you push the spin toward
`a = 0.995` — the prograde side flattens into a "D". That asymmetry is frame
dragging, and you cannot get it without solving the actual Kerr geodesics.

## What's physically real here

- **Geometry**: the Kerr metric in Boyer–Lindquist coordinates. Photons are
  integrated as Hamiltonian flow, `H = ½ g^{μν} p_μ p_ν`, with RK4 and an
  adaptive step. `H = 0` is monitored as an error gauge (`--check`).
- **Camera**: a ZAMO (zero-angular-momentum observer) orthonormal tetrad turns
  each pixel's view direction into the photon's conserved energy `E` and axial
  angular momentum `L_z`.
- **Accretion disk**: a thin equatorial disk from the ISCO (Bardeen's formula,
  responds live to the spin slider) out to 18 M, on exact circular-orbit
  4-velocities with `Ω = 1/(r^{3/2} + a)`.
- **Light from the disk**: the exact relativistic redshift factor
  `g = 1/[u^t (E − Ω L_z)]` — gravitational redshift and Doppler in one number —
  with bolometric beaming `I ∝ g⁴` and blackbody color at temperature `g·T(r)`,
  using a Shakura–Sunyaev radial temperature profile.
- **For free, because the geodesics are real**: gravitational lensing of the
  starfield, the photon ring, higher-order images of the disk (the band "above"
  and "below" the shadow is the far side of the disk), and the asymmetric
  brightness (the approaching side beams at you).

## What's deliberately simplified

Honesty section — this is a visualization, not a research code:

- The disk is **geometrically thin and opaque**, with a procedural turbulence
  texture; no magnetohydrodynamics, no radiative transfer along the ray.
- Temperature uses the Newtonian Shakura–Sunyaev profile, not the fully
  relativistic Novikov–Thorne flux.
- Blackbody → sRGB uses an analytic fit of the Planckian locus.
- Starfield is procedural and not redshifted.
- `f32` everywhere: fine for imaging, not for science-grade precision.

## Verify the physics (don't take our word)

```bash
python kerr_blackhole.py --check
```

runs headless self-tests against known exact results:

1. Schwarzschild critical impact parameter `b_crit = 3√3 M ≈ 5.196 M`:
   a ray at `b = 4.9 M` must fall in, `b = 5.5 M` must escape.
2. Hamiltonian conservation along rays (integration error ≲ 1e-5).
3. Frame dragging at `a = 0.95`: prograde `b = +3.2 M` escapes (it would be
   captured by a non-spinning hole), retrograde `b = −6.3 M` is captured.
4. Bardeen ISCO: `6 M` at `a = 0`, `≈ 1.24 M` at `a = 0.998`.

## Code map

| Equation | Where |
|---|---|
| Kerr Hamiltonian + Hamilton's equations | `geodesic_rhs` |
| RK4 integrator | `rk4_step` |
| ZAMO camera tetrad → (E, L_z, p_r, p_θ) | `camera_ray` |
| Bardeen ISCO | `isco_radius` |
| Circular-orbit Ω, redshift factor g, beaming g⁴ | `shade_disk` |
| Shakura–Sunyaev T(r) | `disk_temperature` |
| Blackbody color | `blackbody_rgb` |

The physics walkthrough with the full equations lives on the workshop site's
demo page.
